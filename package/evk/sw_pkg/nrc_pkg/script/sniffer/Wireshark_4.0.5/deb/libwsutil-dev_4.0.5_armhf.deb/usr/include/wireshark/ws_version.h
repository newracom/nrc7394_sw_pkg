/* ws_version.h.in */

#ifndef __WS_VERSION_H__
#define __WS_VERSION_H__

#define WIRESHARK_VERSION_MAJOR 4
#define WIRESHARK_VERSION_MINOR 0
#define WIRESHARK_VERSION_MICRO 5

#endif /* __WS_VERSION_H__ */
