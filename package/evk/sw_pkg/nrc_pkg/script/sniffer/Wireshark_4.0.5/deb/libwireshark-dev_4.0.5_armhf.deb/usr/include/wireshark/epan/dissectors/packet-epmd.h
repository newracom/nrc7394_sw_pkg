/* packet-epmd.h
 * Definitions for EPMD (Erlang Port Mapper Daemon) messages
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef __PACKET_EPMD_H__
#define __PACKET_EPMD_H__

extern const value_string epmd_version_vals[];

#endif
