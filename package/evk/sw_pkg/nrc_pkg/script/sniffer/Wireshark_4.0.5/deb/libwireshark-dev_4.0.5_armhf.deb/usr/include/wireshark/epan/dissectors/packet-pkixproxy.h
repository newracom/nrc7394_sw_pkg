/* Do not modify this file. Changes will be overwritten.                      */
/* Generated automatically by the ASN.1 to Wireshark dissector compiler       */
/* packet-pkixproxy.h                                                         */
/* asn2wrs.py -b -p pkixproxy -c ./pkixproxy.cnf -s ./packet-pkixproxy-template -D . -O ../.. PKIXProxy.asn */

/* Input file: packet-pkixproxy-template.h */

#line 1 "./asn1/pkixproxy/packet-pkixproxy-template.h"
/* packet-pkixproxy.h
 * Routines for RFC3820 PKIXProxy packet dissection
 *  Ronnie Sahlberg 2004
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PACKET_PKIXPROXY_H
#define PACKET_PKIXPROXY_H

/*#include "packet-pkixproxy-exp.h"*/

#endif  /* PACKET_PKIXPROXY_H */

